
ots_endpoint=http://YDT-DAT-HDS-OTS.cn-shanghai-zty-d01.ots.dcp.dev.ect-it.com
sed -i 's#ots_endpoint#'$ots_endpoint'#g' his_ccs_fee_jour.json
