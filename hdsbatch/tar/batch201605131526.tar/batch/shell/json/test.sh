#!bin/bash
cur_path=`pwd`
echo $cur_path
source $cur_path/config.properties

echo $ODPSaccessId
echo $ODPSaccessKey
